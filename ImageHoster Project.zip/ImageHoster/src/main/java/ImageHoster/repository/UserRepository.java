package ImageHoster.repository;

import ImageHoster.model.User;
import org.springframework.stereotype.Repository;

import javax.persistence.*;

//The annotation is a special type of @Component annotation which describes that the class defines a data repository
@Repository
public class UserRepository {
    //Get an instance of EntityManagerFactory from persistence unit with name as 'imageHoster'
    @PersistenceUnit(unitName = "imagehostler")

    private EntityManagerFactory emf;

    public User registerUser(User user){

        EntityManager entityManager = emf.createEntityManager();
        EntityTransaction transaction = entityManager.getTransaction();
        try {
            transaction.begin();
            entityManager.persist(user);
            transaction.commit();
        }catch (Exception e){
            transaction.rollback();
        }
        return user;
    }
    public User userLogin(User user){
        EntityManager entityManager = emf.createEntityManager();
        Query query = entityManager.createQuery("select u from User u where u.username = :user AND  u.password = :password");
        query.setParameter("user",user.getUsername());
        query.setParameter("password",user.getPassword());
        try {
            return (User) query.getSingleResult();

        }catch (Exception e){
            return  null;
        }

    }
}