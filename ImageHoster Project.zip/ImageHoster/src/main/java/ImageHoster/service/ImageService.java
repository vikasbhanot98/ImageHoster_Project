package ImageHoster.service;

import ImageHoster.model.Image;
import ImageHoster.model.User;
import ImageHoster.model.comment;
import ImageHoster.repository.ImageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;

@Service
public class ImageService {
    @Autowired
    ImageRepository repository;
    private List<Image> images = new ArrayList<>();


    public List<Image> getAllImages() {
        return repository.getAllImages();
    }

    public Image getSingleImage(int id ){
        return repository.getSingleImages(id);

    }
    public comment savecomment(HttpSession session,int id,String text){
        return repository.savecomment(session,id,text);

    }
    public Image editImage(Image newImage){
        return  repository.editNewImage(newImage);
    }

    //The method does not store the image in the database
    public Image uploadImage(Image image, HttpSession session) {
        User u  = (User) session.getAttribute("user");

        image.setUser(u);

        return  repository.uploadImage(image);
        //Simply return from this method as this method does not currently store the image in the database
    }
    public boolean deleteImage(int id){
        return repository.deleteImage(id);
    }

}
